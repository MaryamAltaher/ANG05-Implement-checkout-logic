import { CartLine } from './cart-line';

describe('CartLine', () => {
  it('should create an instance', () => {
    expect(new CartLine()).toBeTruthy();
  });
});
